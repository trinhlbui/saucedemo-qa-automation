import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';

// Credentials are published on the Sauce Demo login page for practice use.
const VALID_USER = 'standard_user';
const VALID_PASS = 'secret_sauce';

test.describe('Login', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.goto();
  });

  test('valid user lands on the products page', async ({ page }) => {
    await loginPage.login(VALID_USER, VALID_PASS);
    await expect(page).toHaveURL(/inventory/);
    await expect(page.locator('[data-test="title"]')).toHaveText('Products');
  });

  test('wrong password shows an error', async () => {
    await loginPage.login(VALID_USER, 'wrong_password');
    await expect(loginPage.errorMessage).toContainText(
      'Username and password do not match'
    );
  });

  test('locked out user cannot log in', async () => {
    await loginPage.login('locked_out_user', VALID_PASS);
    await expect(loginPage.errorMessage).toContainText('locked out');
  });

  test('empty username shows a required-field error', async () => {
    await loginPage.password.fill(VALID_PASS);
    await loginPage.loginButton.click();
    await expect(loginPage.errorMessage).toContainText('Username is required');
  });

  test('empty password shows a required-field error', async () => {
    await loginPage.username.fill(VALID_USER);
    await loginPage.loginButton.click();
    await expect(loginPage.errorMessage).toContainText('Password is required');
  });
});
