import { test, expect } from '@playwright/test';

// JSONPlaceholder is a free fake REST API intended for testing and prototyping.
const BASE = 'https://jsonplaceholder.typicode.com';

test.describe('Posts API', () => {
  test('GET /posts/1 returns the expected post', async ({ request }) => {
    const res = await request.get(`${BASE}/posts/1`);
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body.id).toBe(1);
    expect(body).toHaveProperty('userId');
    expect(body).toHaveProperty('title');
  });

  test('GET /posts?userId=1 returns only that user\'s posts', async ({ request }) => {
    const res = await request.get(`${BASE}/posts`, { params: { userId: 1 } });
    expect(res.status()).toBe(200);
    const posts = await res.json();
    expect(posts.length).toBeGreaterThan(0);
    for (const post of posts) {
      expect(post.userId).toBe(1);
    }
  });

  test('POST /posts creates a resource', async ({ request }) => {
    const payload = { title: 'qa practice', body: 'hello', userId: 1 };
    const res = await request.post(`${BASE}/posts`, { data: payload });
    expect(res.status()).toBe(201);
    const body = await res.json();
    expect(body.title).toBe(payload.title);
    expect(body).toHaveProperty('id');
  });

  test('GET a non-existent post returns 404', async ({ request }) => {
    const res = await request.get(`${BASE}/posts/999999`);
    expect(res.status()).toBe(404);
  });
});
