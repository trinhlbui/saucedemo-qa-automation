import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ShopPage } from '../pages/ShopPage';
import { CheckoutPage } from '../pages/CheckoutPage';

test.describe('Shopping and checkout', () => {
  let shop: ShopPage;
  let checkout: CheckoutPage;

  test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    shop = new ShopPage(page);
    checkout = new CheckoutPage(page);

    await loginPage.goto();
    await loginPage.login('standard_user', 'secret_sauce');
    await expect(page).toHaveURL(/inventory/);
  });

  test('adding an item updates the cart badge', async () => {
    await shop.addToCart('sauce-labs-backpack');
    await expect(shop.cartBadge).toHaveText('1');
  });

  test('user can complete an order end to end', async () => {
    await shop.addToCart('sauce-labs-backpack');
    await shop.openCart();
    await checkout.checkoutButton.click();
    await checkout.fillInfo('Test', 'User', '90001');
    await checkout.continueButton.click();
    await checkout.finishButton.click();
    await expect(checkout.completeHeader).toHaveText('Thank you for your order!');
  });

  test('checkout requires a first name', async () => {
    await shop.addToCart('sauce-labs-backpack');
    await shop.openCart();
    await checkout.checkoutButton.click();
    await checkout.continueButton.click();
    await expect(checkout.errorMessage).toContainText('First Name is required');
  });

  test('sorting by price low to high orders items ascending', async () => {
    await shop.sortBy('lohi');
    const prices = await shop.getPrices();
    const sorted = [...prices].sort((a, b) => a - b);
    expect(prices).toEqual(sorted);
  });
});
